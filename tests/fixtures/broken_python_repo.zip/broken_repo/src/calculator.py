def divide(a: int, b: int) -> int:
    # Bug: multiplication instead of division
    return a * b
