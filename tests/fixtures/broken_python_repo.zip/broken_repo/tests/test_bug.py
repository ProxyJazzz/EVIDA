import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'src'))
from calculator import divide

def test_divide_bug():
    assert divide(10, 2) == 5
